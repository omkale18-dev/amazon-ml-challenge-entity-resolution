"""
Scalable candidate generation (blocking) for business entity resolution.

Strategy (v2 — rewritten for 2M+ / 5M+ row datasets):
  1. Normalize business names (reuses utils/normalize.py).
  2. Token blocking with frequency filtering:
     - Explode names into tokens, skip tokens < 2 chars.
     - Remove tokens appearing in > MAX_TOKEN_FREQ records (too common,
       e.g. "inc", "co", "ltd" — these caused the MemoryError).
     - Remove tokens where s1_count * other_count > PAIR_BUDGET
       (hard safety cap so no single token can blow up memory).
     - Build an integer-mapped inverted index (numpy int32 arrays) for
       memory efficiency.
     - For each source1 entity, collect candidate IDs via shared tokens.
  3. Prefix blocking as fallback for entities with zero token candidates.
  4. Loads source2 and source3 one at a time to halve peak memory.

Estimated peak RAM: ~3-5 GB on the full 2.2M/5M/5.3M dataset.

Usage:
    python generate_candidates.py --source1 ../dataset/train/train_source1.tsv --source2 ../dataset/train/train_source2.tsv --source3 ../dataset/train/train_source3.tsv --out ../output/train_candidate_pairs.tsv
"""

import argparse
import gc
import os
import sys
import time

import numpy as np
import pandas as pd

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from utils.normalize import normalize_name  # noqa: E402

# ---------------------------------------------------------------------------
# Configuration — tune these if recall is too low or memory is still tight
# ---------------------------------------------------------------------------
MAX_CANDIDATES_PER_ENTITY = 50   # max candidates kept per source1 entity
MAX_TOKEN_FREQ = 5000            # tokens in > this many records are skipped
PAIR_BUDGET = 500_000            # max s1_count * other_count for one token
PREFIX_LEN = 4                   # fallback prefix-blocking key length
PREFIX_MAX_FREQ = 10_000         # skip prefixes appearing in > this many records


def load_source(path: str) -> pd.DataFrame:
    """Load a source TSV, keeping only the columns needed for blocking."""
    print(f"  Loading {os.path.basename(path)}...", end=" ", flush=True)
    df = pd.read_csv(
        path, sep="\t", dtype=str,
        usecols=["entity_id", "business_name"],
    ).fillna("")
    df["norm_name"] = df["business_name"].apply(normalize_name)
    print(f"{len(df):,} rows")
    return df


def explode_tokens(df: pd.DataFrame) -> pd.DataFrame:
    """Explode normalized names into (entity_id, token) pairs."""
    tdf = df[["entity_id", "norm_name"]].copy()
    tdf["token"] = tdf["norm_name"].str.split()
    tdf = tdf.explode("token")
    tdf = tdf.dropna(subset=["token"])
    tdf = tdf[tdf["token"].str.len() >= 2]
    tdf = tdf[["entity_id", "token"]].drop_duplicates()
    return tdf


def compute_safe_tokens(s1_tok: pd.DataFrame, other_tok: pd.DataFrame) -> set:
    """Return tokens that are safe for blocking (not too common, pair budget OK)."""
    s1_counts = s1_tok["token"].value_counts().rename("s1_count")
    other_counts = other_tok["token"].value_counts().rename("other_count")

    # Inner-join on shared tokens only
    counts = pd.DataFrame(
        {"s1_count": s1_counts, "other_count": other_counts}
    ).dropna()

    mask = (
        (counts["s1_count"] <= MAX_TOKEN_FREQ)
        & (counts["other_count"] <= MAX_TOKEN_FREQ)
        & (counts["s1_count"] * counts["other_count"] <= PAIR_BUDGET)
    )

    safe = set(counts[mask].index)
    total_shared = len(counts)
    skipped = total_shared - int(mask.sum())
    print(f"    {len(safe):,} safe tokens / {total_shared:,} shared "
          f"({skipped:,} filtered as too common)")
    return safe


def run_blocking_pass(s1_df: pd.DataFrame, other_df: pd.DataFrame) -> dict:
    """
    Token-overlap blocking between s1 and another source.

    Returns {s1_entity_id: [candidate_entity_ids, ...]}.
    Uses integer-mapped inverted index for memory efficiency.
    """
    t0 = time.time()

    print("  Exploding tokens...")
    s1_tok = explode_tokens(s1_df)
    other_tok = explode_tokens(other_df)

    print("  Computing safe tokens...")
    safe = compute_safe_tokens(s1_tok, other_tok)
    if not safe:
        print("  WARNING: no safe tokens found — all tokens too common!")
        return {}

    # ----- build integer-mapped inverted index for the 'other' side -----
    print("  Building inverted index (int-mapped)...")
    eid_array = other_df["entity_id"].values                    # string array
    eid_to_idx = pd.Series(np.arange(len(eid_array), dtype=np.int32),
                           index=eid_array)

    other_safe = other_tok[other_tok["token"].isin(safe)].copy()
    other_safe["idx"] = other_safe["entity_id"].map(eid_to_idx).values.astype(np.int32)

    inv_index: dict[str, np.ndarray] = {}
    for tok, grp in other_safe.groupby("token"):
        inv_index[tok] = grp["idx"].values

    del other_safe, other_tok
    gc.collect()

    # ----- iterate over s1 entities -----
    print("  Collecting candidates...")
    s1_safe = s1_tok[s1_tok["token"].isin(safe)]
    del s1_tok
    gc.collect()

    # group s1 tokens by entity
    s1_by_entity = s1_safe.groupby("entity_id")["token"].apply(list)
    del s1_safe
    gc.collect()

    results: dict[str, list[str]] = {}
    n = len(s1_by_entity)
    for i, (eid, tokens) in enumerate(s1_by_entity.items()):
        chunks = []
        total = 0
        for tok in tokens:
            arr = inv_index.get(tok)
            if arr is not None:
                chunks.append(arr)
                total += len(arr)
                if total >= MAX_CANDIDATES_PER_ENTITY * 5:
                    break                       # collected enough, stop early
        if chunks:
            combined = np.unique(np.concatenate(chunks))
            if len(combined) > MAX_CANDIDATES_PER_ENTITY:
                combined = combined[:MAX_CANDIDATES_PER_ENTITY]
            results[eid] = [eid_array[j] for j in combined]

        if (i + 1) % 500_000 == 0:
            print(f"    {i+1:,}/{n:,} entities...")

    elapsed = time.time() - t0
    print(f"  Token blocking: {len(results):,}/{len(s1_df):,} entities "
          f"got candidates ({elapsed:.0f}s)")
    return results


def prefix_blocking(s1_df: pd.DataFrame, other_df: pd.DataFrame,
                    existing: dict, prefix_len: int = PREFIX_LEN,
                    max_cands: int = 20) -> dict:
    """Fallback: add candidates for s1 entities with none, using name prefix."""
    missing = set(s1_df["entity_id"]) - set(existing.keys())
    if not missing:
        print("  Prefix blocking: not needed (all entities already have candidates)")
        return existing

    print(f"  Prefix blocking for {len(missing):,} entities w/o candidates...")

    # build prefix index for other source
    other_pf = other_df[["entity_id", "norm_name"]].copy()
    other_pf["prefix"] = other_pf["norm_name"].str[:prefix_len]
    other_pf = other_pf[other_pf["prefix"].str.len() >= prefix_len]

    # skip ultra-common prefixes
    pfx_counts = other_pf["prefix"].value_counts()
    common = set(pfx_counts[pfx_counts > PREFIX_MAX_FREQ].index)
    other_pf = other_pf[~other_pf["prefix"].isin(common)]

    pfx_index = other_pf.groupby("prefix")["entity_id"].apply(list).to_dict()
    del other_pf
    gc.collect()

    s1_miss = s1_df[s1_df["entity_id"].isin(missing)].copy()
    s1_miss["prefix"] = s1_miss["norm_name"].str[:prefix_len]

    added = 0
    for pfx, grp in s1_miss.groupby("prefix"):
        if pfx and len(pfx) >= prefix_len and pfx in pfx_index:
            cands = pfx_index[pfx][:max_cands]
            for eid in grp["entity_id"]:
                existing[eid] = cands
                added += 1

    print(f"    +{added:,} entities via prefix blocking")
    return existing


# -----------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Scalable candidate-pair generation via token blocking"
    )
    parser.add_argument("--source1", required=True)
    parser.add_argument("--source2", required=True)
    parser.add_argument("--source3", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    print("Loading source1...")
    s1 = load_source(args.source1)

    # ---- pass 1: source1 vs source2 ----
    print(f"\n{'='*60}")
    print("Blocking source1 vs source2...")
    print(f"{'='*60}")
    s2 = load_source(args.source2)
    cands_2 = run_blocking_pass(s1, s2)
    cands_2 = prefix_blocking(s1, s2, cands_2)
    del s2
    gc.collect()

    # ---- pass 2: source1 vs source3 ----
    print(f"\n{'='*60}")
    print("Blocking source1 vs source3...")
    print(f"{'='*60}")
    s3 = load_source(args.source3)
    cands_3 = run_blocking_pass(s1, s3)
    cands_3 = prefix_blocking(s1, s3, cands_3)
    del s3
    gc.collect()

    # ---- write output ----
    print(f"\nWriting {args.out}...")
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)

    n_with = 0
    total_cands = 0
    with open(args.out, "w", encoding="utf-8") as f:
        f.write("source1_entity_id\tcandidate_entity_ids\n")
        for eid in s1["entity_id"]:
            all_cands = set()
            if eid in cands_2:
                all_cands.update(cands_2[eid])
            if eid in cands_3:
                all_cands.update(cands_3[eid])
            cand_list = sorted(all_cands)[:MAX_CANDIDATES_PER_ENTITY]
            f.write(f"{eid}\t{','.join(cand_list)}\n")
            if cand_list:
                n_with += 1
                total_cands += len(cand_list)

    avg = total_cands / len(s1) if len(s1) else 0
    print(f"Done. {len(s1):,} source1 entities, "
          f"{n_with:,} have >=1 candidate, "
          f"avg {avg:.1f} candidates/entity.")


if __name__ == "__main__":
    main()
