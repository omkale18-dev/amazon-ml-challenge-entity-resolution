"""
Train a gradient-boosted classifier on labeled training pairs, then
predict matches on the test candidate pairs, applying a threshold tuned
for F_0.5.

v2: Streamlined for scale — test features are scored in streaming chunks
    to keep RAM minimal and prevent MemoryError on 70M+ pairs.

Usage:
    python model/train_and_predict.py \
        --train-features ../output/train_pair_features_labeled.tsv \
        --test-features ../output/test_pair_features.tsv \
        --test-source1 ../dataset/test/test_source1.tsv \
        --out ../output/matching_results.tsv
"""

import argparse
import os
import sys
import time
from collections import defaultdict

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.model_selection import GroupShuffleSplit

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "eval"))
from score_f05 import f_beta  # noqa: E402

FEATURE_COLS = [
    "name_exact_match",
    "name_jaccard",
    "name_levenshtein_ratio",
    "name_token_sort_ratio",
    "name_partial_ratio",
    "addr_jaccard",
    "addr_levenshtein_ratio",
    "addr_token_sort_ratio",
    "country_match",
    "name_len_diff",
]

PREDICT_CHUNK_SIZE = 500_000


def train_model(train_df: pd.DataFrame) -> LGBMClassifier:
    X = train_df[FEATURE_COLS]
    y = train_df["label"]
    model = LGBMClassifier(
        n_estimators=300,
        num_leaves=31,
        learning_rate=0.05,
        class_weight="balanced",  # matches tend to be a small minority of candidate pairs
        random_state=42,
        verbosity=-1,
        n_jobs=-1,  # use all CPU cores
    )
    model.fit(X, y)
    return model


def pick_threshold_by_f05(model, val_df: pd.DataFrame) -> float:
    """
    Sweep thresholds on a held-out validation slice (grouped by source1_entity_id
    so no entity leaks between train/val), pick the one maximizing macro F_0.5.
    """
    val_df = val_df.copy()
    val_df["score"] = model.predict_proba(val_df[FEATURE_COLS])[:, 1]

    best_threshold, best_f05 = 0.5, -1.0
    for threshold in np.arange(0.3, 0.96, 0.05):
        per_entity_scores = []
        for s1_id, group in val_df.groupby("source1_entity_id"):
            predicted = set(group.loc[group["score"] >= threshold, "candidate_entity_id"])
            actual = set(group.loc[group["label"] == 1, "candidate_entity_id"])
            if not actual and not predicted:
                per_entity_scores.append(1.0)
                continue
            tp = len(predicted & actual)
            precision = tp / len(predicted) if predicted else (1.0 if not actual else 0.0)
            recall = tp / len(actual) if actual else (1.0 if not predicted else 0.0)
            per_entity_scores.append(f_beta(precision, recall, beta=0.5))
        macro_f05 = sum(per_entity_scores) / len(per_entity_scores)
        print(f"  threshold={threshold:.2f}  macro_F0.5={macro_f05:.4f}")
        if macro_f05 > best_f05:
            best_f05, best_threshold = macro_f05, threshold

    print(f"Best threshold: {best_threshold:.2f} (macro F_0.5={best_f05:.4f})")
    return best_threshold


def predict_matches_chunked(model, test_features_path: str, threshold: float, all_test_s1_ids: list) -> pd.DataFrame:
    """
    Score test features in chunks of PREDICT_CHUNK_SIZE to stay memory safe.
    Only stores positive predictions (score >= threshold).
    """
    matches = defaultdict(list)
    total_scored = 0
    total_matched_pairs = 0
    t0 = time.time()

    print(f"Scoring test candidate features in chunks of {PREDICT_CHUNK_SIZE:,}...")
    for chunk in pd.read_csv(test_features_path, sep="\t", chunksize=PREDICT_CHUNK_SIZE):
        scores = model.predict_proba(chunk[FEATURE_COLS])[:, 1]
        mask = scores >= threshold
        if mask.any():
            matched_chunk = chunk[mask]
            for s1_id, cand_id in zip(matched_chunk["source1_entity_id"], matched_chunk["candidate_entity_id"]):
                matches[s1_id].append(cand_id)
            total_matched_pairs += int(mask.sum())

        total_scored += len(chunk)
        elapsed = time.time() - t0
        rate = total_scored / elapsed if elapsed > 0 else 0
        print(f"  Scored {total_scored:,} pairs ({rate:,.0f} pairs/s) | {total_matched_pairs:,} matches found")

    print(f"Building final output for all {len(all_test_s1_ids):,} source1 test entities...")
    rows = []
    for eid in all_test_s1_ids:
        matched_list = matches.get(eid, [])
        if matched_list:
            sorted_unique = sorted(set(matched_list))
            rows.append({"source1_entity_id": eid, "matched_entity_ids": ",".join(sorted_unique)})
        else:
            rows.append({"source1_entity_id": eid, "matched_entity_ids": ""})

    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-features", required=True,
                        help="labeled training pair features (from label_pairs.py)")
    parser.add_argument("--test-features", required=True,
                        help="unlabeled test pair features (from build_features.py)")
    parser.add_argument("--test-source1", required=True,
                        help="test_source1.tsv, needed to include entities with zero candidates")
    parser.add_argument("--out", required=True)
    parser.add_argument("--threshold", type=float, default=None,
                        help="fixed threshold; if omitted, tuned automatically for F_0.5")
    args = parser.parse_args()

    print("Loading labeled training features...")
    train_df = pd.read_csv(args.train_features, sep="\t")
    print(f"  {len(train_df):,} labeled training rows loaded")

    print("Splitting train/val by source1 entity (no leakage)...")
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    train_idx, val_idx = next(
        splitter.split(train_df, groups=train_df["source1_entity_id"])
    )
    fit_df, val_df = train_df.iloc[train_idx], train_df.iloc[val_idx]

    print(f"Training LightGBM on {len(fit_df):,} pairs, tuning threshold on {len(val_df):,} pairs...")
    model = train_model(fit_df)

    threshold = args.threshold
    if threshold is None:
        print("Sweeping thresholds for best macro F_0.5...")
        threshold = pick_threshold_by_f05(model, val_df)
    else:
        print(f"Using fixed threshold={threshold}")

    print("Loading all test source1 entity IDs...")
    all_test_s1 = pd.read_csv(args.test_source1, sep="\t", dtype=str)["entity_id"].tolist()

    result_df = predict_matches_chunked(model, args.test_features, threshold, all_test_s1)
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    result_df.to_csv(args.out, sep="\t", index=False)

    n_with_match = (result_df["matched_entity_ids"] != "").sum()
    print(f"\nDone! {len(result_df):,} entities written to {args.out}")
    print(f"  {n_with_match:,} entities predicted with >=1 match")
    print(f"  {len(result_df) - n_with_match:,} singletons (no match)")


if __name__ == "__main__":
    main()
