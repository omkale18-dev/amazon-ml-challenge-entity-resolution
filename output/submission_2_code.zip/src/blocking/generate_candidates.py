"""
Ultra-Fast, High-Recall Multi-Key Blocking for Business Entity Resolution.

Optimizations:
  1. NumPy int32 array inverted index (C-speed lookups, ~150MB RAM).
  2. np.unique + np.argpartition ranking for candidate selection (10,000+ queries/s).
  3. Bounded bucket size (MAX_BUCKET_SIZE=5000) skips massive uninformative words.
  4. Compound Address Keys (Building/Street Number + Locality/Street Word).
  5. Clean Name Tokens (excluding legal suffixes).
  6. Optional --max-s1 flag (e.g. 150000 for fast training candidate generation).

Usage:
    # For TRAIN (fast: ~30 seconds for 150k entities):
    python blocking/generate_candidates.py \
        --source1 ../dataset/train/train_source1.tsv \
        --source2 ../dataset/train/train_source2.tsv \
        --source3 ../dataset/train/train_source3.tsv \
        --out ../output/train_candidate_pairs.tsv \
        --max-s1 150000

    # For TEST (full: all 1.73M entities in ~3 minutes):
    python blocking/generate_candidates.py \
        --source1 ../dataset/test/test_source1.tsv \
        --source2 ../dataset/test/test_source2.tsv \
        --source3 ../dataset/test/test_source3.tsv \
        --out ../output/candidate_pairs.tsv
"""

import argparse
import gc
import os
import re
import sys
import time
from collections import defaultdict

import numpy as np
import pandas as pd

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

MAX_CANDS_PER_SOURCE = 20
MAX_BUCKET_SIZE = 5_000  # buckets larger than 5,000 records are too generic

STOPWORDS_NAME = {
    "inc", "corp", "ltd", "llc", "pvt", "co", "the", "and", "of", "in",
    "for", "group", "services", "solutions", "international", "enterprises",
    "technologies", "private", "limited", "corporation", "incorporated",
    "company", "holdings", "trust", "society", "association", "center",
    "centre", "foundation", "institute", "india", "us", "usa",
}

STOPWORDS_ADDR = {
    "st", "street", "rd", "road", "ave", "avenue", "dr", "drive", "ln", "lane",
    "blvd", "boulevard", "fl", "floor", "apt", "apartment", "unit", "bldg",
    "building", "suite", "pmb", "box", "po", "near", "opp", "behind", "beside",
    "plot", "block", "first", "second", "third", "main", "cross", "phase",
    "sector", "stage", "city", "state", "india", "usa", "us", "no", "flat",
}


def clean_words(text: str, stopwords: set) -> list[str]:
    clean = re.sub(r"[^\w\s]", " ", str(text).lower())
    return [w for w in clean.split() if len(w) >= 3 and w not in stopwords and not w.isdigit()]


def extract_blocking_keys(name: str, addr: str) -> list[str]:
    n_words = clean_words(name, STOPWORDS_NAME)
    a_words = clean_words(addr, STOPWORDS_ADDR)

    clean_addr = re.sub(r"[^\w\s]", " ", str(addr).lower())
    a_nums = [w for w in clean_addr.split() if w.isdigit() and len(w) <= 8]

    keys = []
    # 1. Distinctive Name tokens
    for w in n_words[:5]:
        keys.append("N:" + w)

    # 2. Compound Address Keys: building/street number + street word
    for num in a_nums[:3]:
        for w in a_words[:3]:
            keys.append(f"C:{num}_{w}")

    # 3. Distinctive Address tokens
    for w in a_words[:3]:
        keys.append("A:" + w)

    return keys


def load_source_fields(path: str, max_rows: int = 0) -> tuple[list[str], list[str], list[str]]:
    print(f"  Loading {os.path.basename(path)}...", end=" ", flush=True)
    t0 = time.time()
    df = pd.read_csv(
        path, sep="\t", dtype=str,
        usecols=["entity_id", "business_name", "business_address"],
        nrows=max_rows if max_rows > 0 else None,
    ).fillna("")
    eids = df["entity_id"].tolist()
    names = df["business_name"].tolist()
    addrs = df["business_address"].tolist()
    print(f"{len(df):,} rows ({time.time() - t0:.1f}s)")
    return eids, names, addrs


def build_numpy_inverted_index(names: list[str], addrs: list[str]) -> dict[str, np.ndarray]:
    print("  Building inverted index...", end=" ", flush=True)
    t0 = time.time()
    raw_index = defaultdict(list)

    for idx, (name, addr) in enumerate(zip(names, addrs)):
        for k in extract_blocking_keys(name, addr):
            raw_index[k].append(idx)

    # Convert to contiguous int32 arrays, discarding noisy large buckets
    index = {}
    skipped = 0
    for k, lst in raw_index.items():
        if len(lst) <= MAX_BUCKET_SIZE:
            index[k] = np.array(lst, dtype=np.int32)
        else:
            skipped += 1

    del raw_index
    gc.collect()
    print(f"{len(index):,} keys ({skipped:,} common keys pruned) in {time.time() - t0:.1f}s")
    return index


def query_candidates_numpy(
    s1_names: list[str],
    s1_addrs: list[str],
    index: dict[str, np.ndarray],
    other_eids: list[str],
    max_cands: int = MAX_CANDS_PER_SOURCE,
) -> list[list[str]]:
    print(f"  Querying candidates for {len(s1_names):,} source1 entities...")
    t0 = time.time()
    results = []

    for i, (name, addr) in enumerate(zip(s1_names, s1_addrs)):
        keys = extract_blocking_keys(name, addr)
        arrays = [index[k] for k in keys if k in index]

        if arrays:
            cat = np.concatenate(arrays)
            vals, counts = np.unique(cat, return_counts=True)
            if len(vals) > max_cands:
                top_idx = np.argpartition(-counts, max_cands)[:max_cands]
                # sort top candidates by count descending
                top_sorted = top_idx[np.argsort(-counts[top_idx])]
                results.append([other_eids[idx] for idx in vals[top_sorted]])
            else:
                sorted_idx = np.argsort(-counts)
                results.append([other_eids[idx] for idx in vals[sorted_idx]])
        else:
            results.append([])

        if (i + 1) % 500_000 == 0:
            elapsed = time.time() - t0
            rate = (i + 1) / elapsed if elapsed > 0 else 0
            print(f"    {i + 1:,}/{len(s1_names):,} queries completed ({rate:,.0f} queries/s)...")

    total_time = time.time() - t0
    final_rate = len(s1_names) / total_time if total_time > 0 else 0
    print(f"  Matching finished in {total_time:.1f}s ({final_rate:,.0f} queries/s)")
    return results


def main():
    parser = argparse.ArgumentParser(description="High-Speed High-Recall Multi-Key Candidate Generation")
    parser.add_argument("--source1", required=True)
    parser.add_argument("--source2", required=True)
    parser.add_argument("--source3", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--max-s1", type=int, default=0,
                        help="Optional: max source1 rows to query (e.g. 150000 for train set). 0 = all.")
    args = parser.parse_args()

    # Load Source 1
    print("\n--- Loading Source 1 ---")
    s1_eids, s1_names, s1_addrs = load_source_fields(args.source1, max_rows=args.max_s1)

    # Pass 1: Source 1 vs Source 2
    print("\n" + "=" * 60)
    print("Pass 1: Blocking Source 1 vs Source 2")
    print("=" * 60)
    s2_eids, s2_names, s2_addrs = load_source_fields(args.source2)
    s2_index = build_numpy_inverted_index(s2_names, s2_addrs)
    del s2_names, s2_addrs
    gc.collect()

    s2_candidates = query_candidates_numpy(s1_names, s1_addrs, s2_index, s2_eids)
    del s2_index, s2_eids
    gc.collect()

    # Pass 2: Source 1 vs Source 3
    print("\n" + "=" * 60)
    print("Pass 2: Blocking Source 1 vs Source 3")
    print("=" * 60)
    s3_eids, s3_names, s3_addrs = load_source_fields(args.source3)
    s3_index = build_numpy_inverted_index(s3_names, s3_addrs)
    del s3_names, s3_addrs
    gc.collect()

    s3_candidates = query_candidates_numpy(s1_names, s1_addrs, s3_index, s3_eids)
    del s3_index, s3_eids
    gc.collect()

    # Write combined candidate pairs
    print(f"\nWriting final candidate pairs to {args.out}...")
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)

    with_cands = 0
    total_cands = 0

    with open(args.out, "w", encoding="utf-8") as f:
        f.write("source1_entity_id\tcandidate_entity_ids\n")
        for eid, cands2, cands3 in zip(s1_eids, s2_candidates, s3_candidates):
            merged = []
            seen = set()
            for c in cands2 + cands3:
                if c not in seen:
                    merged.append(c)
                    seen.add(c)

            if merged:
                with_cands += 1
                total_cands += len(merged)
                f.write(f"{eid}\t{','.join(merged)}\n")
            else:
                f.write(f"{eid}\t\n")

    avg_cands = total_cands / len(s1_eids) if s1_eids else 0
    print(f"\nDone! {len(s1_eids):,} entities written.")
    print(f"  {with_cands:,} entities have >=1 candidate ({100*with_cands/len(s1_eids):.1f}%)")
    print(f"  Average candidates per entity: {avg_cands:.1f}")


if __name__ == "__main__":
    main()
