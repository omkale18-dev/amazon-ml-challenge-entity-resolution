"""
Train LightGBM on labeled training pairs, then stream test candidate pairs
and predict matches directly on the fly.

Memory-safe architecture:
  1. Trains LightGBM on train_pair_features_labeled.tsv with fine-grained F_0.5 sweep.
  2. Loads test sources compactly into memory (~800MB RAM, plain strings only, NO giant set objects).
  3. Streams candidate_pairs.tsv line-by-line in batches.
  4. Computes RapidFuzz features in memory and scores on-the-fly.
  5. Bypasses the 6GB intermediate test_pair_features.tsv file completely!
  6. Peak RAM remains under 1.5 GB at all times.

Usage:
    python model/train_and_predict.py \
        --train-features ../output/train_pair_features_labeled.tsv \
        --candidates ../output/candidate_pairs.tsv \
        --test-source1 ../dataset/test/test_source1.tsv \
        --test-source2 ../dataset/test/test_source2.tsv \
        --test-source3 ../dataset/test/test_source3.tsv \
        --out ../output/matching_results.tsv
"""

import argparse
import gc
import os
import re
import sys
import time
from collections import defaultdict

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from rapidfuzz import fuzz
from sklearn.model_selection import GroupShuffleSplit

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "eval"))
from score_f05 import f_beta  # noqa: E402
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from utils.normalize import normalize_name, normalize_address  # noqa: E402

FEATURE_COLS = [
    "name_exact_match",
    "name_jaccard",
    "name_levenshtein_ratio",
    "name_token_sort_ratio",
    "name_partial_ratio",
    "addr_exact_match",
    "addr_jaccard",
    "addr_levenshtein_ratio",
    "addr_token_sort_ratio",
    "addr_num_match",
    "country_match",
    "name_len_diff",
]

BATCH_ENTITIES = 20_000


def jaccard(set_a: set, set_b: set) -> float:
    if not set_a and not set_b:
        return 1.0
    if not set_a or not set_b:
        return 0.0
    inter = len(set_a & set_b)
    union = len(set_a | set_b)
    return inter / union if union else 0.0


def train_model(train_df: pd.DataFrame) -> LGBMClassifier:
    X = train_df[FEATURE_COLS]
    y = train_df["label"]
    model = LGBMClassifier(
        n_estimators=400,
        num_leaves=63,
        learning_rate=0.05,
        class_weight="balanced",
        random_state=42,
        verbosity=-1,
        n_jobs=-1,
    )
    model.fit(X, y)
    return model


def pick_threshold_by_f05(model, val_df: pd.DataFrame) -> float:
    """Pre-organizes validation data so 15 threshold evaluations take < 1 second."""
    print("  Calculating validation probabilities...")
    scores = model.predict_proba(val_df[FEATURE_COLS])[:, 1]

    val_by_entity = defaultdict(list)
    for s1_id, cand_id, label, score in zip(
        val_df["source1_entity_id"],
        val_df["candidate_entity_id"],
        val_df["label"],
        scores,
    ):
        val_by_entity[s1_id].append((cand_id, label, score))

    print(f"  Sweeping thresholds on {len(val_by_entity):,} validation entities...")
    best_threshold, best_f05 = 0.5, -1.0
    for threshold in np.arange(0.15, 0.90, 0.05):
        per_entity_scores = []
        for s1_id, pairs in val_by_entity.items():
            predicted = {cand for cand, _, score in pairs if score >= threshold}
            actual = {cand for cand, label, _ in pairs if label == 1}
            if not actual and not predicted:
                per_entity_scores.append(1.0)
                continue
            tp = len(predicted & actual)
            precision = tp / len(predicted) if predicted else (1.0 if not actual else 0.0)
            recall = tp / len(actual) if actual else (1.0 if not predicted else 0.0)
            per_entity_scores.append(f_beta(precision, recall, beta=0.5))

        macro_f05 = sum(per_entity_scores) / len(per_entity_scores) if per_entity_scores else 0.0
        print(f"    threshold={threshold:.2f}  macro_F0.5={macro_f05:.4f}")
        if macro_f05 > best_f05:
            best_f05, best_threshold = macro_f05, threshold

    print(f"\n  >>> Optimal threshold: {best_threshold:.2f} (Macro F_0.5 = {best_f05:.4f})")
    return best_threshold


def load_compact_records(s1_path: str, s2_path: str, s3_path: str) -> dict[str, tuple[str, str, str]]:
    """Loads plain normalized strings and country. Minimal RAM overhead (~800MB for 11M rows)."""
    records = {}
    for path in [s1_path, s2_path, s3_path]:
        print(f"  Loading {os.path.basename(path)}...", end=" ", flush=True)
        t0 = time.time()
        df = pd.read_csv(
            path, sep="\t", dtype=str,
            usecols=lambda c: c in ["entity_id", "business_name", "business_address", "country"],
        ).fillna("")

        has_country = "country" in df.columns
        ids = df["entity_id"].values
        names = df["business_name"].values
        addrs = df["business_address"].values
        countries = df["country"].values if has_country else [""] * len(df)

        count = 0
        for eid, name, addr, country in zip(ids, names, addrs, countries):
            if eid not in records:
                records[eid] = (
                    normalize_name(name),
                    normalize_address(addr),
                    country.strip().lower(),
                )
                count += 1
        print(f"{count:,} records in {time.time() - t0:.1f}s")

    print(f"  Total records in compact cache: {len(records):,}")
    return records


def stream_predict_on_the_fly(
    model: LGBMClassifier,
    threshold: float,
    candidates_path: str,
    records: dict[str, tuple[str, str, str]],
    all_s1_ids: list[str],
    out_path: str,
):
    """
    Streams candidate_pairs.tsv line by line, featurizes in memory batches,
    predicts with LightGBM, and streams matches directly to matching_results.tsv.
    Keeps RAM below 1.5 GB at all times.
    """
    print(f"\nStreaming candidates & predicting on-the-fly to {out_path}...")
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)

    t0 = time.time()
    total_entities = 0
    total_pairs = 0
    total_matches = 0
    matches_dict = {}

    batch_entities = []

    with open(candidates_path, "r", encoding="utf-8") as f:
        f.readline()  # skip header
        for line in f:
            parts = line.strip().split("\t")
            if not parts:
                continue
            s1_id = parts[0]
            cand_str = parts[1] if len(parts) > 1 else ""
            cands = [c.strip() for c in cand_str.split(",") if c.strip()]
            batch_entities.append((s1_id, cands))

            if len(batch_entities) >= BATCH_ENTITIES:
                process_batch(batch_entities, records, model, threshold, matches_dict)
                total_entities += len(batch_entities)
                total_pairs += sum(len(c) for _, c in batch_entities)
                total_matches = sum(len(v) for v in matches_dict.values())
                batch_entities.clear()

                elapsed = time.time() - t0
                pct = min(100.0, total_entities / len(all_s1_ids) * 100)
                rate = total_pairs / elapsed if elapsed > 0 else 0
                print(
                    f"  {pct:5.1f}% | {total_entities:,}/{len(all_s1_ids):,} entities | "
                    f"{total_pairs:,} pairs scored ({rate:,.0f} pairs/s) | {total_matches:,} matches"
                )

        if batch_entities:
            process_batch(batch_entities, records, model, threshold, matches_dict)
            total_entities += len(batch_entities)
            total_pairs += sum(len(c) for _, c in batch_entities)
            batch_entities.clear()

    print(f"\nWriting final predictions for all {len(all_s1_ids):,} test entities...")
    with open(out_path, "w", encoding="utf-8") as out_f:
        out_f.write("source1_entity_id\tmatched_entity_ids\n")
        matched_entities_count = 0
        for eid in all_s1_ids:
            cand_matches = matches_dict.get(eid, [])
            if cand_matches:
                matched_entities_count += 1
                out_f.write(f"{eid}\t{','.join(sorted(set(cand_matches)))}\n")
            else:
                out_f.write(f"{eid}\t\n")

    total_time = time.time() - t0
    print(f"Done! Written to {out_path} in {total_time:.1f}s")
    print(f"  {matched_entities_count:,} entities predicted with >=1 match ({100*matched_entities_count/len(all_s1_ids):.1f}%)")
    print(f"  {len(all_s1_ids) - matched_entities_count:,} singletons (no match)")


def process_batch(
    batch: list[tuple[str, list[str]]],
    records: dict,
    model: LGBMClassifier,
    threshold: float,
    matches_dict: dict,
):
    pair_meta = []
    features_list = []

    for s1_id, cands in batch:
        rec_a = records.get(s1_id)
        if rec_a is None or not cands:
            continue

        n_a, a_a, c_a = rec_a
        n_tok_a = set(n_a.split())
        a_tok_a = set(a_a.split())
        nums_a = set(re.findall(r"\d+", a_a))
        len_n_a = len(n_a)

        for cand_id in cands:
            rec_b = records.get(cand_id)
            if rec_b is None:
                continue

            n_b, a_b, c_b = rec_b
            n_tok_b = set(n_b.split())
            a_tok_b = set(a_b.split())
            nums_b = set(re.findall(r"\d+", a_b))

            # Features
            name_exact = int(n_a == n_b and n_a != "")
            name_jacc = jaccard(n_tok_a, n_tok_b)
            name_lev = fuzz.ratio(n_a, n_b) / 100.0
            name_sort = fuzz.token_sort_ratio(n_a, n_b) / 100.0
            name_part = fuzz.partial_ratio(n_a, n_b) / 100.0

            addr_exact = int(a_a == a_b and a_a != "")
            addr_jacc = jaccard(a_tok_a, a_tok_b)
            addr_lev = fuzz.ratio(a_a, a_b) / 100.0
            addr_sort = fuzz.token_sort_ratio(a_a, a_b) / 100.0
            addr_num_match = int(bool(nums_a & nums_b))

            cntry_match = int(c_a == c_b and c_a != "")
            len_diff = abs(len_n_a - len(n_b))

            features_list.append([
                name_exact, name_jacc, name_lev, name_sort, name_part,
                addr_exact, addr_jacc, addr_lev, addr_sort, addr_num_match,
                cntry_match, len_diff,
            ])
            pair_meta.append((s1_id, cand_id))

    if not features_list:
        return

    # Batch prediction with LightGBM
    X = np.array(features_list, dtype=np.float32)
    scores = model.predict_proba(X)[:, 1]

    mask = scores >= threshold
    if mask.any():
        matched_indices = np.where(mask)[0]
        for idx in matched_indices:
            s1_id, cand_id = pair_meta[idx]
            if s1_id not in matches_dict:
                matches_dict[s1_id] = []
            matches_dict[s1_id].append(cand_id)


def main():
    parser = argparse.ArgumentParser(description="End-to-End Low-Memory Train & Direct Predictor")
    parser.add_argument("--train-features", required=True)
    parser.add_argument("--candidates", required=True)
    parser.add_argument("--test-source1", required=True)
    parser.add_argument("--test-source2", required=True)
    parser.add_argument("--test-source3", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--threshold", type=float, default=None)
    args = parser.parse_args()

    # Step 1: Load training features & Train LightGBM
    print("\n--- Step 1: Loading Training Features & Training Model ---")
    train_df = pd.read_csv(args.train_features, sep="\t")
    print(f"  Loaded {len(train_df):,} labeled training rows ({train_df['label'].sum():,} positives)")

    print("  Splitting train/val by source1 entity...")
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    train_idx, val_idx = next(splitter.split(train_df, groups=train_df["source1_entity_id"]))
    fit_df, val_df = train_df.iloc[train_idx], train_df.iloc[val_idx]

    print(f"  Fitting LightGBM on {len(fit_df):,} pairs...")
    model = train_model(fit_df)

    threshold = args.threshold
    if threshold is None:
        threshold = pick_threshold_by_f05(model, val_df)
    else:
        print(f"  Using specified threshold: {threshold}")

    # Free training memory
    del train_df, fit_df, val_df
    gc.collect()

    # Step 2: Load compact test records (< 800MB RAM)
    print("\n--- Step 2: Loading Compact Test Records ---")
    records = load_compact_records(args.test_source1, args.test_source2, args.test_source3)

    print("\nLoading test entity IDs...")
    all_s1_ids = pd.read_csv(args.test_source1, sep="\t", dtype=str)["entity_id"].tolist()

    # Step 3: Stream candidates & Predict directly on the fly
    print("\n--- Step 3: Direct Streaming Prediction ---")
    stream_predict_on_the_fly(model, threshold, args.candidates, records, all_s1_ids, args.out)


if __name__ == "__main__":
    main()
